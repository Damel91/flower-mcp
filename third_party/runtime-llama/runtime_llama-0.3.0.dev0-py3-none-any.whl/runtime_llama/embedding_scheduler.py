"""Adapter-scoped, bounded admission for external embedding requests."""

from __future__ import annotations

from collections import deque
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass
from threading import Condition
from typing import Any, Callable

from runtime_llama.errors import LLMBackendError


@dataclass(eq=False)
class _Job:
    run: Callable[[str], Any]
    check: Callable[[], None]
    future: Future


class EmbeddingScheduler:
    """Reserve global and replica slots before dispatch; never retry a job."""

    def __init__(self, parallelism: int, queue_size: int, replicas: dict[str, int]):
        self.parallelism, self.queue_size = parallelism, queue_size
        self._limits = dict(replicas)
        self._aliases = tuple(replicas)
        self._replica_active = dict.fromkeys(replicas, 0)
        self._replica_peak = dict.fromkeys(replicas, 0)
        self._condition = Condition()
        self._queue: deque[_Job] = deque()
        self._active = self._peak_active = self._peak_queued = 0
        self._next_alias = 0
        self._closed = False
        self._executor = ThreadPoolExecutor(
            max_workers=parallelism, thread_name_prefix="runtime_llama_embedding"
        )

    def _available_alias(self) -> str | None:
        if self._active >= self.parallelism:
            return None
        for offset in range(len(self._aliases)):
            index = (self._next_alias + offset) % len(self._aliases)
            alias = self._aliases[index]
            if self._replica_active[alias] < self._limits[alias]:
                self._next_alias = (index + 1) % len(self._aliases)
                return alias
        return None

    def _dispatch(self, job: _Job, alias: str) -> None:
        self._active += 1
        self._replica_active[alias] += 1
        self._peak_active = max(self._peak_active, self._active)
        self._replica_peak[alias] = max(
            self._replica_peak[alias], self._replica_active[alias]
        )
        self._executor.submit(self._run, job, alias)

    def _run(self, job: _Job, alias: str) -> None:
        try:
            job.check()
            result = job.run(alias)
        except BaseException as exc:
            job.future.set_exception(exc)
        else:
            job.future.set_result(result)
        finally:
            with self._condition:
                self._active -= 1
                self._replica_active[alias] -= 1
                self._pump()
                self._condition.notify_all()

    def _pump(self) -> None:
        while self._queue and not self._closed:
            job = self._queue[0]
            try:
                job.check()
            except BaseException as exc:
                self._queue.popleft()
                job.future.set_exception(exc)
                continue
            alias = self._available_alias()
            if alias is None:
                break
            self._queue.popleft()
            self._dispatch(job, alias)

    def submit(self, run: Callable[[str], Any], check: Callable[[], None]) -> Future:
        job = _Job(run, check, Future())
        with self._condition:
            while True:
                check()
                if self._closed:
                    raise LLMBackendError("llamacpp_embedding_adapter_closed")
                self._pump()
                alias = self._available_alias() if not self._queue else None
                if alias is not None:
                    self._dispatch(job, alias)
                    return job.future
                if len(self._queue) < self.queue_size:
                    self._queue.append(job)
                    self._peak_queued = max(self._peak_queued, len(self._queue))
                    return job.future
                self._condition.wait(0.05)

    def snapshot(self) -> dict[str, Any]:
        with self._condition:
            return {
                "in_flight": self._active,
                "queued": len(self._queue),
                "peak_in_flight": self._peak_active,
                "peak_queued": self._peak_queued,
                "replicas": {
                    alias: {
                        "in_flight": self._replica_active[alias],
                        "peak_in_flight": self._replica_peak[alias],
                        "max_in_flight": self._limits[alias],
                    }
                    for alias in self._aliases
                },
            }

    def close(self) -> None:
        with self._condition:
            self._closed = True
            while self._queue:
                self._queue.popleft().future.set_exception(
                    LLMBackendError("llamacpp_embedding_adapter_closed")
                )
            self._condition.notify_all()
        self._executor.shutdown(wait=True)

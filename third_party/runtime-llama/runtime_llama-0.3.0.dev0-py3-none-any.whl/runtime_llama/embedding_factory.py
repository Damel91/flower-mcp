"""Embedding factory import preserved as a migration convenience."""

from runtime_llama.factory import build_embedding_adapter

__all__ = ["build_embedding_adapter"]
